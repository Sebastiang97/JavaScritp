
var calculadora = {};

calculadora = (function presionando(){
	var operacion="",num="",numpresionado = "",signos="",
	z=false,cont = true,conts=true,contp=true,contnum = false,
	r=0,acumulado=0,numero2=0,c=0,acumulador=0,a=0,t,
	resultado = "",re=""

	function contador(){
		
		num = num + numpresionado
		document.getElementById("display").innerHTML = num.substring(0, 8);
		numpresionado =""
		if(contnum){
			if(cont){
				acumulado = parseFloat(num)
				cont = false
			}else if(!cont){
				numero2 = parseFloat(num)
				operaciones()
			}
		}
	}
	function achicarTecla(tecla){
		tecla.style.transform = "scale(0.95, 0.92)";
	}
	document.getElementById("0").onclick = function	(){
		t = document.getElementById("0")
		achicarTecla(t)
		if(num!="0"){
			numpresionado = "0"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("0")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("1").onclick = function(){
		t = document.getElementById("1")
		achicarTecla(t)					
		if(num!="0"){
			numpresionado = "1"
			contador();			
		}else{
			num=""
			numpresionado = "1"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("1")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("2").onclick = function(){
		t = document.getElementById("2")
		achicarTecla(t)					
		if(num!="0"){
			numpresionado = "2"
		 	contador();
		}else{
			num=""
			numpresionado ="2"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("2")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("3").onclick = function(){
		t = document.getElementById("3")
		achicarTecla(t)			
		if(num!="0"){
			numpresionado = "3"
			contador();
		}else{
			num=""
			numpresionado ="3"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("3")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("4").onclick = function(){
		t = document.getElementById("4")
		achicarTecla(t)
		if(num!="0"){
			numpresionado = "4"
			contador();
		}else{
			num=""
			numpresionado ="4"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("4")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("5").onclick = function(){
		t = document.getElementById("5")	
		achicarTecla(t)
		if(num!="0"){
			numpresionado = "5"
			contador();
		}else{
			num=""
			numpresionado ="5"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("5")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("6").onclick = function(){
		t = document.getElementById("6")
		achicarTecla(t)
		if(num!="0"){
			numpresionado = "6"
			contador();
		}else{
			num=""
			numpresionado ="6"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("6")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("7").onclick = function(){
		t = document.getElementById("7")
		achicarTecla(t)
		if(num!="0"){
			numpresionado = "7"
			contador();
		}else{
			num=""
			numpresionado ="7"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("7")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("8").onclick = function(){
		t = document.getElementById("8")
		achicarTecla(t)
		if(num!="0"){
			numpresionado = "8"
			contador();
		}else{
			num=""
			numpresionado ="8"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("8")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("9").onclick = function(){
		t = document.getElementById("9")
		achicarTecla(t)
		if(num!="0"){
			numpresionado = "9"
			contador();
		}else{
			num=""
			numpresionado ="9"
			contador();
		}
		setTimeout(function(){
			t = document.getElementById("9")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("on").onclick = function(){
		t = document.getElementById("on")
		achicarTecla(t)
		r = 0
		acumulador=0
		numero2 = 0
		cont = true
		conts = true 
		contp = true
		operacion = ""
		num = "0"
		numpresionado=""
		document.getElementById("display").innerHTML = num;
		setTimeout(function(){
			t = document.getElementById("on")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("punto").onclick = function(){
		t = document.getElementById("punto")
		achicarTecla(t)
		console.log(c)
		if(r == 0 ){
			signos = "."; 
			num = "0"+signos
			contp = false;
			document.getElementById("display").innerHTML = num
		}else if(num!="0" && contp){
			signos = "."; 
			num = num+signos
			contp = false;
			document.getElementById("display").innerHTML = num
		}else if(num=="0" && contp){
			signos = "."; 
			num = "0"+signos
			contp = false;
			document.getElementById("display").innerHTML = num
		}
		setTimeout(function(){
			t = document.getElementById("punto")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("sign").onclick = function(){
		t = document.getElementById("sign")
		achicarTecla(t)
		if (!z || num == 0) {
			num = "0"
			document.getElementById("display").innerHTML = num
		}else if(num!="0" && conts){
			signos = "-"; 
			num = signos+num
			conts = false;
			document.getElementById("display").innerHTML = num
		}else if(!conts){
			num = num *-1
			document.getElementById("display").innerHTML = num
		}
		setTimeout(function(){
			t = document.getElementById("sign")
			t.style.transform = "";
		}, 100);
		z=true
	}
	document.getElementById("dividido").onclick = function(){
		t = document.getElementById("dividido")
		achicarTecla(t)
		contnum = true
		contador()
		operacion = "d"
		sig()
		cont = false
		setTimeout(function(){
			t = document.getElementById("dividido")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("por").onclick = function(){
		t = document.getElementById("por")
		achicarTecla(t)
		contnum = true
		contador()
		operacion = "m"	
		sig()
		cont = false
		setTimeout(function(){
			t = document.getElementById("por")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("mas").onclick = function(){
		t = document.getElementById("mas")
		achicarTecla(t)
		contnum = true
		contador()
		operacion = "s"
		sig()
		cont = false
				setTimeout(function(){
			t = document.getElementById("mas")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("menos").onclick = function(){
		t = document.getElementById("menos")
		achicarTecla(t)
		contnum = true
		contador()
		operacion = "r"
		sig()
		cont = false
		setTimeout(function(){
			t = document.getElementById("menos")
			t.style.transform = "";
		}, 100);
	}
	document.getElementById("igual").onclick = function(){
		t = document.getElementById("igual")
		achicarTecla(t)
		contnum = true
		conts = true 
		contp = true
		contador()	
		a++
		if(a>2){
			operaciones()
		}
		re = r
		resultado= re.toString();
		document.getElementById("display").innerHTML = resultado.substring(0, 8);
		num = ""
		r = parseFloat(resultado)
		acumulado = parseFloat(resultado)
		contnum = false
		setTimeout(function(){
			t = document.getElementById("igual")
			t.style.transform = "";
		}, 100);
	}
	function sig(){
		num = ""
		document.getElementById("display").innerHTML = ""
		conts = true 
		contp = true
		a=0
		contnum = false
		console.log("acumulado "+acumulado)
		console.log
	}
	function operaciones(){
		switch(operacion){
			case "s": 
				r = acumulado+numero2;console.log(r+"="+acumulado+"+"+numero2)
				acumulado = r
				operacion =""
			break;
			case "r": 
				r = acumulado-numero2;console.log(r+"="+acumulado+"-"+numero2)	
				acumulado = r	
				operacion =""
			break;
			case "m": 
				r = acumulado*numero2;console.log(r+"="+acumulado+"*"+numero2)	
				acumulado = r
				operacion =""
			break;
			case "d": 
				r = acumulado/numero2;console.log(r+"="+acumulado+"/"+numero2)	
				acumulado = r
				operacion =""
			break;
		}
	}
}())




